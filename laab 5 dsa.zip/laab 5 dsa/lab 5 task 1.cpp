#include <iostream>
using namespace std;

template <typename T>
class AbstractStack {
public:
    virtual void push(T value) = 0;
    virtual T pop() = 0;
    virtual T top() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;
    virtual ~AbstractStack() {}
};

template <typename T>
class myStack : public AbstractStack<T> {
private:
    T* arr;
    int maxSize;
    int topIndex;
public:
    myStack(int size = 10) {
        maxSize = size;
        arr = new T[maxSize];
        topIndex = -1;
    }

    ~myStack() {
        delete[] arr;
    }

    void push(T value) override {
        if (isFull()) {
            cout << "Stack is full. Cannot push.\n";
            return;
        }
        arr[++topIndex] = value;
    }

    T pop() override {
        if (isEmpty()) {
            throw runtime_error("Stack is empty. Cannot pop.");
        }
        return arr[topIndex--];
    }

    T top() const override {
        if (isEmpty()) {
            throw runtime_error("Stack is empty. No top element.");
        }
        return arr[topIndex];
    }

    bool isEmpty() const override {
        return topIndex == -1;
    }

    bool isFull() const override {
        return topIndex == maxSize - 1;
    }

    void display() const {
        if (isEmpty()) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "Stack elements (top to bottom):\n";
        for (int i = topIndex; i >= 0; --i) {
            cout << arr[i] << endl;
        }
    }
};

int main() {
    myStack<int> stack(5);
    int choice, value;

    do {
        cout << "\nMenu:\n";
        cout << "1. Push\n";
        cout << "2. Pop\n";
        cout << "3. Top\n";
        cout << "4. Check if Empty\n";
        cout << "5. Check if Full\n";
        cout << "6. Display Stack\n";
        cout << "0. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value to push: ";
            cin >> value;
            stack.push(value);
            break;
        case 2:
            try {
                cout << "Popped value: " << stack.pop() << endl;
            }
            catch (exception& e) {
                cout << e.what() << endl;
            }
            break;
        case 3:
            try {
                cout << "Top value: " << stack.top() << endl;
            }
            catch (exception& e) {
                cout << e.what() << endl;
            }
            break;
        case 4:
            cout << (stack.isEmpty() ? "Stack is empty.\n" : "Stack is not empty.\n");
            break;
        case 5:
            cout << (stack.isFull() ? "Stack is full.\n" : "Stack is not full.\n");
            break;
        case 6:
            stack.display();
            break;
        case 0:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}
