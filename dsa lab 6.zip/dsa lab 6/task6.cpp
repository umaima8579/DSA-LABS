#include <iostream>
#include <queue>
using namespace std;

struct Package {
    int id;
    string address;
    int startTime;
    int endTime;
};

class DeliverySystem {
    queue<Package> q;

public:
    void enqueue(int id, string address, int start, int end) {
        Package p;
        p.id = id;
        p.address = address;
        p.startTime = start;
        p.endTime = end;
        q.push(p);
        cout << "Package " << id << " added.\n";
    }

    void dequeue() {
        if (q.empty()) {
            cout << "No packages to deliver.\n";
            return;
        }
        cout << "Delivered Package ID: " << q.front().id << endl;
        q.pop();
    }

    void front() {
        if (q.empty()) {
            cout << "No packages in queue.\n";
            return;
        }
        Package p = q.front();
        cout << "Front Package:\n";
        cout << "ID: " << p.id << "\nAddress: " << p.address
            << "\nWindow: " << p.startTime << " - " << p.endTime << endl;
    }

    void display() {
        if (q.empty()) {
            cout << "No packages in queue.\n";
            return;
        }
        queue<Package> temp = q;
        cout << "All Packages:\n";
        while (!temp.empty()) {
            Package p = temp.front();
            cout << "ID: " << p.id << ", Address: " << p.address
                << ", Window: " << p.startTime << "-" << p.endTime << endl;
            temp.pop();
        }
    }

    void timeToDeliver(int currentTime) {
        while (!q.empty()) {
            Package p = q.front();
            if (currentTime >= p.startTime && currentTime <= p.endTime) {
                cout << "Delivering Package ID: " << p.id << endl;
                q.pop();
                return;
            }
            else {
                cout << "Package ID " << p.id << " expired. Skipped.\n";
                q.pop();
            }
        }
        cout << "No deliverable packages at current time.\n";
    }
};

int main() {
    DeliverySystem system;
    int choice;

    do {
        cout << "\n1. Add Package\n2. Deliver Front Package\n3. View Front Package\n4. Display All Packages\n5. Deliver By Current Time\n6. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            int id, start, end;
            string address;
            cout << "Enter Package ID: ";
            cin >> id;
            cin.ignore();
            cout << "Enter Address: ";
            getline(cin, address);
            cout << "Enter Start Time: ";
            cin >> start;
            cout << "Enter End Time: ";
            cin >> end;
            system.enqueue(id, address, start, end);
        }
        else if (choice == 2) {
            system.dequeue();
        }
        else if (choice == 3) {
            system.front();
        }
        else if (choice == 4) {
            system.display();
        }
        else if (choice == 5) {
            int currentTime;
            cout << "Enter current time: ";
            cin >> currentTime;
            system.timeToDeliver(currentTime);
        }
        else if (choice == 6) {
            cout << "Exiting.\n";
        }
        else {
            cout << "Invalid choice.\n";
        }
    } while (choice != 6);

    return 0;
}
