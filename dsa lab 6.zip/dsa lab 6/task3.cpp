#include <iostream>
#include <queue>
#include <stack>
using namespace std;

class MyQueue {
    queue<int> q;

public:
    void enqueue(int val) {
        q.push(val);
    }

    void dequeue() {
        if (!q.empty()) q.pop();
    }

    int front() {
        if (!q.empty()) return q.front();
        return -1;
    }

    bool isEmpty() {
        return q.empty();
    }

    int size() {
        return q.size();
    }

    void reverseFirstK(int k) {
        if (k <= 1 || q.empty()) return;
        if (k > q.size()) k = q.size();

        stack<int> s;
        for (int i = 0; i < k; i++) {
            s.push(q.front());
            q.pop();
        }

        while (!s.empty()) {
            q.push(s.top());
            s.pop();
        }

        int remaining = q.size() - k;
        for (int i = 0; i < remaining; i++) {
            q.push(q.front());
            q.pop();
        }
    }

    void display() {
        queue<int> temp = q;
        while (!temp.empty()) {
            cout << temp.front() << " ";
            temp.pop();
        }
        cout << endl;
    }
};

int main() {
    MyQueue q;
    int n, val, k;

    cout << "Enter number of elements: ";
    cin >> n;

    cout << "Enter elements: ";
    for (int i = 0; i < n; i++) {
        cin >> val;
        q.enqueue(val);
    }

    cout << "Enter K: ";
    cin >> k;

    cout << "Original Queue: ";
    q.display();

    q.reverseFirstK(k);

    cout << "Modified Queue: ";
    q.display();

    return 0;
}
