#include <iostream>
#include <cmath>
using namespace std;

template<typename Type>
class List {
protected:
    Type* arr;
    int maxSize;
    int currentSize;
public:
    List(int size = 10) {
        maxSize = size;
        currentSize = 0;
        arr = new Type[maxSize];
    }

    List(const List& other) {
        maxSize = other.maxSize;
        currentSize = other.currentSize;
        arr = new Type[maxSize];
        for (int i = 0; i < currentSize; i++) {
            arr[i] = other.arr[i];
        }
    }

    virtual ~List() {
        delete[] arr;
    }

    virtual void addElementAtFirstIndex(Type element) = 0;
    virtual void addElementAtLastIndex(Type element) = 0;
    virtual Type removeElementFromEnd() = 0;
    virtual void removeElementFromStart() = 0;
};

template<typename Type>
class MyList : public List<Type> {
public:
    MyList(int size = 10) : List<Type>(size) {}

    MyList(const MyList& other) : List<Type>(other) {}

    ~MyList() {}

    void addElementAtFirstIndex(Type element) override {
        if (this->currentSize >= this->maxSize)
            return;
        for (int i = this->currentSize; i > 0; --i) {
            this->arr[i] = this->arr[i - 1];
        }
        this->arr[0] = element;
        this->currentSize++;
    }

    void addElementAtLastIndex(Type element) override {
        if (this->currentSize >= this->maxSize)
            return;
        this->arr[this->currentSize++] = element;
    }

    Type removeElementFromEnd() override {
        if (this->currentSize == 0)
            throw runtime_error("List is empty");
        return this->arr[--this->currentSize];
    }

    void removeElementFromStart() override {
        if (this->currentSize == 0)
            return;
        for (int i = 0; i < this->currentSize - 1; ++i) {
            this->arr[i] = this->arr[i + 1];
        }
        this->currentSize--;
    }

    bool empty() const {
        return this->currentSize == 0;
    }

    bool full() const {
        return this->currentSize == this->maxSize;
    }

    int size() const {
        return this->currentSize;
    }

    bool insertAt(int index, Type value) {
        if (index < 0 || index > this->currentSize || this->currentSize >= this->maxSize)
            return false;
        for (int i = this->currentSize; i > index; --i) {
            this->arr[i] = this->arr[i - 1];
        }
        this->arr[index] = value;
        this->currentSize++;
        return true;
    }

    Type last() const {
        if (this->currentSize == 0)
            throw runtime_error("List is empty");
        return this->arr[this->currentSize - 1];
    }

    bool search(Type value) const {
        for (int i = 0; i < this->currentSize; ++i) {
            if (this->arr[i] == value)
                return true;
        }
        return false;
    }

    void display() const {
        for (int i = 0; i < this->currentSize; ++i) {
            cout << this->arr[i] << " ";
        }
        cout << endl;
    }
};

template<typename Type>
class CustomList : public MyList<Type> {
public:
    CustomList(int size = 10) : MyList<Type>(size) {}

    CustomList(const CustomList& other) : MyList<Type>(other) {}

    ~CustomList() {}

    bool isPrime(Type num) {
        if (num < 2)
            return false;
        for (int i = 2; i <= sqrt(num); ++i) {
            if (num % i == 0)
                return false;
        }
        return true;
    }

    Type sum_ofPrime() {
        Type sum = 0;
        for (int i = 0; i < this->currentSize; ++i) {
            if (isPrime(this->arr[i]))
                sum += this->arr[i];
        }
        return sum;
    }

    Type secondMaxEven() {
        Type max1 = -1, max2 = -1;
        for (int i = 0; i < this->currentSize; i++) {
            if (this->arr[i] % 2 == 0) {
                if (this->arr[i] > max1) {
                    max2 = max1;
                    max1 = this->arr[i];
                }
                else if (this->arr[i] > max2 && this->arr[i] != max1) {
                    max2 = this->arr[i];
                }
            }
        }
        return max2;
    }

    Type secondMinOdd() {
        Type min1 = INT_MAX, min2 = INT_MAX;
        for (int i = 0; i < this->currentSize; i++) {
            if (this->arr[i] % 2 != 0) {
                if (this->arr[i] < min1) {
                    min2 = min1;
                    min1 = this->arr[i];
                }
                else if (this->arr[i] < min2 && this->arr[i] != min1) {
                    min2 = this->arr[i];
                }
            }
        }
        return min2;
    }

    void printDuplicates() {
        bool found = false;
        for (int i = 0; i < this->currentSize; i++) {
            for (int j = i + 1; j < this->currentSize; j++) {
                if (this->arr[i] == this->arr[j]) {
                    cout << this->arr[i] << " ";
                    break;
                }
            }
        }
        cout << endl;
    }

    void rotateClockwaise(int r) {
        int mid = this->currentSize / 2;
        r = r % mid;
        reverse(this->arr, this->arr + mid);
        reverse(this->arr, this->arr + r);
        reverse(this->arr + r, this->arr + mid);
        reverse(this->arr + mid, this->arr + this->currentSize);
        reverse(this->arr + mid, this->arr + mid + r);
        reverse(this->arr + mid + r, this->arr + this->currentSize);
    }

    void rotateanitclockwaise(int rt) {
        int mid = this->currentSize / 2;
        rt = rt % mid;
        reverse(this->arr, this->arr + mid);
        reverse(this->arr, this->arr + mid - rt);
        reverse(this->arr + mid - rt, this->arr + mid);
        reverse(this->arr + mid, this->arr + this->currentSize);
        reverse(this->arr + mid, this->arr + this->currentSize - rt);
        reverse(this->arr + this->currentSize - rt, this->arr + this->currentSize);
    }

private:
    void reverse(Type* start, Type* end) {
        end--;
        while (start < end) {
            swap(*start, *end);
            start++;
            end--;
        }
    }
};

int main() {
    CustomList<int> clist(20);
    int choice, value, index, r;

    do {
        cout << "\nMenu:\n";
        cout << "1. Add element at first index\n";
        cout << "2. Add element at last index\n";
        cout << "3. Remove element from end\n";
        cout << "4. Remove element from start\n";
        cout << "5. Insert at index\n";
        cout << "6. Display list\n";
        cout << "7. Sum of prime numbers\n";
        cout << "8. Second maximum even number\n";
        cout << "9. Second minimum odd number\n";
        cout << "10. Print duplicates\n";
        cout << "11. Rotate clockwise\n";
        cout << "12. Rotate anti-clockwise\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value: ";
            cin >> value;
            clist.addElementAtFirstIndex(value);
            break;
        case 2:
            cout << "Enter value: ";
            cin >> value;
            clist.addElementAtLastIndex(value);
            break;
        case 3:
            try {
                cout << "Removed: " << clist.removeElementFromEnd() << endl;
            }
            catch (exception& e) {
                cout << e.what() << endl;
            }
            break;
        case 4:
            clist.removeElementFromStart();
            break;
        case 5:
            cout << "Enter index and value: ";
            cin >> index >> value;
            if (clist.insertAt(index, value))
                cout << "Inserted successfully.\n";
            else
                cout << "Failed to insert.\n";
            break;
        case 6:
            clist.display();
            break;
        case 7:
            cout << "Sum of primes: " << clist.sum_ofPrime() << endl;
            break;
        case 8:
            cout << "Second maximum even: " << clist.secondMaxEven() << endl;
            break;
        case 9:
            cout << "Second minimum odd: " << clist.secondMinOdd() << endl;
            break;
        case 10:
            cout << "Duplicates: ";
            clist.printDuplicates();
            break;
        case 11:
            cout << "Enter r: ";
            cin >> r;
            clist.rotateClockwaise(r);
            break;
        case 12:
            cout << "Enter rt: ";
            cin >> rt;
            clist.rotateanitclockwaise(rt);
            break;
        case 0:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}
