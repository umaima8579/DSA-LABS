
#include <iostream>
#include <string>
using namespace std;

struct Student {
    string name;
    string priority;
    Student* next;
};

int getPriorityValue(string p) {
    if (p == "research") return 3;
    if (p == "assignment") return 2;
    return 1;
}

class ReservationList {
private:
    Student* head;

public:
    ReservationList() {
        head = nullptr;
    }

    void addStudent(string name, string priority) {
        Student* newStudent = new Student{ name, priority, nullptr };
        if (head == nullptr || getPriorityValue(priority) > getPriorityValue(head->priority)) {
            newStudent->next = head;
            head = newStudent;
            return;
        }
        Student* current = head;
        while (current->next != nullptr &&
            getPriorityValue(current->next->priority) >= getPriorityValue(priority)) {
            current = current->next;
        }
        newStudent->next = current->next;
        current->next = newStudent;
    }

    void removeStudent(string name) {
        if (head == nullptr) return;
        if (head->name == name) {
            Student* temp = head;
            head = head->next;
            delete temp;
            return;
        }
        Student* current = head;
        while (current->next != nullptr && current->next->name != name) {
            current = current->next;
        }
        if (current->next != nullptr) {
            Student* temp = current->next;
            current->next = temp->next;
            delete temp;
        }
    }

    void updatePriority(string name, string newPriority) {
        removeStudent(name);
        addStudent(name, newPriority);
    }

    void displayList() {
        Student* current = head;
        while (current != nullptr) {
            cout << current->name << " (" << current->priority << ") -> ";
            current = current->next;
        }
        cout << "NULL" << endl;
    }

    int countStudents() {
        int count = 0;
        Student* current = head;
        while (current != nullptr) {
            count++;
            current = current->next;
        }
        return count;
    }

    void serveNextStudent() {
        if (head == nullptr) return;
        Student* temp = head;
        cout << "Serving: " << head->name << " (" << head->priority << ")" << endl;
        head = head->next;
        delete temp;
    }
};

int main() {
    ReservationList book1, book2;

    book1.addStudent("Ali", "assignment");
    book1.addStudent("Fatima", "research");
    book1.addStudent("Ahmed", "casual");
    book1.addStudent("Sara", "assignment");

    book2.addStudent("Usman", "research");
    book2.addStudent("Zara", "casual");
    book2.addStudent("Hassan", "assignment");

    cout << "\nBook 1 Reservation List:\n";
    book1.displayList();

    cout << "\nBook 2 Reservation List:\n";
    book2.displayList();

    cout << "\nAli updated to 'research' priority for Book 1:\n";
    book1.updatePriority("Ali", "research");
    book1.displayList();

    cout << "\nHassan cancels reservation for Book 2:\n";
    book2.removeStudent("Hassan");
    book2.displayList();

    cout << "\nServing next student in Book 1:\n";
    book1.serveNextStudent();
    book1.displayList();

    cout
