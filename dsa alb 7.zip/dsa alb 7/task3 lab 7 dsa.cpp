#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* head = nullptr;

void insertAtPosition(int value, int position) {
    Node* newNode = new Node{ value, nullptr };
    if (position == 1) {
        newNode->next = head;
        head = newNode;
        return;
    }
    Node* temp = head;
    for (int i = 1; i < position - 1 && temp != nullptr; i++) {
        temp = temp->next;
    }
    if (temp == nullptr) return;
    newNode->next = temp->next;
    temp->next = newNode;
}

void deleteAtPosition(int position) {
    if (head == nullptr) return;
    if (position == 1) {
        Node* temp = head;
        head = head->next;
        delete temp;
        return;
    }
    Node* temp = head;
    for (int i = 1; i < position - 1 && temp->next != nullptr; i++) {
        temp = temp->next;
    }
    if (temp->next == nullptr) return;
    Node* delNode = temp->next;
    temp->next = delNode->next;
    delete delNode;
}

bool searchElement(int value) {
    Node* temp = head;
    while (temp != nullptr) {
        if (temp->data == value) return true;
        temp = temp->next;
    }
    return false;
}

int countNodes() {
    int count = 0;
    Node* temp = head;
    while (temp != nullptr) {
        count++;
        temp = temp->next;
    }
    return count;
}

void displayList() {
    Node* temp = head;
    while (temp != nullptr) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;
}

int main() {
    int choice, value, position;
    while (true) {
        cout << "\nMenu:\n";
        cout << "1. Insert at specific position\n";
        cout << "2. Delete at specific position\n";
        cout << "3. Search for an element\n";
        cout << "4. Count total nodes\n";
        cout << "5. Display list\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value and position: ";
            cin >> value >> position;
            insertAtPosition(value, position);
            break;
        case 2:
            cout << "Enter position to delete: ";
            cin >> position;
            deleteAtPosition(position);
            break;
        case 3:
            cout << "Enter value to search: ";
            cin >> value;
            if (searchElement(value))
                cout << "Element found\n";
            else
                cout << "Element not found\n";
            break;
        case 4:
            cout << "Total nodes: " << countNodes() << endl;
            break;
        case 5:
            displayList();
            break;
        case 6:
            return 0;
        default:
            cout << "Invalid choice\n";
        }
    }
}
