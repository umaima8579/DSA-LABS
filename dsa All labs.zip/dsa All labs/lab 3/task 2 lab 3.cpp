#include <iostream>
using namespace std;

template<typename Type>
class List {
protected:
    Type* arr;
    int maxSize;
    int currentSize;
public:
    List(int size = 10) {
        maxSize = size;
        currentSize = 0;
        arr = new Type[maxSize];
    }

    List(const List& other) {
        maxSize = other.maxSize;
        currentSize = other.currentSize;
        arr = new Type[maxSize];
        for (int i = 0; i < currentSize; i++) {
            arr[i] = other.arr[i];
        }
    }

    virtual ~List() {
        delete[] arr;
    }

    virtual void addElementAtFirstIndex(Type element) = 0;
    virtual void addElementAtLastIndex(Type element) = 0;
    virtual Type removeElementFromEnd() = 0;
    virtual void removeElementFromStart() = 0;
};

template<typename Type>
class MyList : public List<Type> {
public:
    MyList(int size = 10) : List<Type>(size) {}

    MyList(const MyList& other) : List<Type>(other) {}

    ~MyList() {}

    void addElementAtFirstIndex(Type element) override {
        if (this->currentSize >= this->maxSize)
            return;
        for (int i = this->currentSize; i > 0; --i) {
            this->arr[i] = this->arr[i - 1];
        }
        this->arr[0] = element;
        this->currentSize++;
    }

    void addElementAtLastIndex(Type element) override {
        if (this->currentSize >= this->maxSize)
            return;
        this->arr[this->currentSize++] = element;
    }

    Type removeElementFromEnd() override {
        if (this->currentSize == 0)
            throw runtime_error("List is empty");
        return this->arr[--this->currentSize];
    }

    void removeElementFromStart() override {
        if (this->currentSize == 0)
            return;
        for (int i = 0; i < this->currentSize - 1; ++i) {
            this->arr[i] = this->arr[i + 1];
        }
        this->currentSize--;
    }

    bool empty() const {
        return this->currentSize == 0;
    }

    bool full() const {
        return this->currentSize == this->maxSize;
    }

    int size() const {
        return this->currentSize;
    }

    bool insertAt(int index, Type value) {
        if (index < 0 || index > this->currentSize || this->currentSize >= this->maxSize)
            return false;
        for (int i = this->currentSize; i > index; --i) {
            this->arr[i] = this->arr[i - 1];
        }
        this->arr[index] = value;
        this->currentSize++;
        return true;
    }

    Type last() const {
        if (this->currentSize == 0)
            throw runtime_error("List is empty");
        return this->arr[this->currentSize - 1];
    }

    bool search(Type value) const {
        for (int i = 0; i < this->currentSize; ++i) {
            if (this->arr[i] == value)
                return true;
        }
        return false;
    }

    void display() const {
        for (int i = 0; i < this->currentSize; ++i) {
            cout << this->arr[i] << " ";
        }
        cout << endl;
    }
};

int main() {
    MyList<int> myList(10);
    int choice, value, index;

    do {
        cout << "\nMenu:\n";
        cout << "1. Add element at first index\n";
        cout << "2. Add element at last index\n";
        cout << "3. Remove element from end\n";
        cout << "4. Remove element from start\n";
        cout << "5. Insert at index\n";
        cout << "6. Display list\n";
        cout << "7. Check if empty\n";
        cout << "8. Check if full\n";
        cout << "9. Get size\n";
        cout << "10. Get last element\n";
        cout << "11. Search element\n";
        cout << "0. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter value: ";
            cin >> value;
            myList.addElementAtFirstIndex(value);
            break;
        case 2:
            cout << "Enter value: ";
            cin >> value;
            myList.addElementAtLastIndex(value);
            break;
        case 3:
            try {
                cout << "Removed: " << myList.removeElementFromEnd() << endl;
            }
            catch (exception& e) {
                cout << e.what() << endl;
            }
            break;
        case 4:
            myList.removeElementFromStart();
            break;
        case 5:
            cout << "Enter index and value: ";
            cin >> index >> value;
            if (myList.insertAt(index, value))
                cout << "Inserted successfully.\n";
            else
                cout << "Failed to insert.\n";
            break;
        case 6:
            myList.display();
            break;
        case 7:
            cout << (myList.empty() ? "List is empty.\n" : "List is not empty.\n");
            break;
        case 8:
            cout << (myList.full() ? "List is full.\n" : "List is not full.\n");
            break;
        case 9:
            cout << "Current size: " << myList.size() << endl;
            break;
        case 10:
            try {
                cout << "Last element: " << myList.last() << endl;
            }
            catch (exception& e) {
                cout << e.what() << endl;
            }
            break;
        case 11:
            cout << "Enter value to search: ";
            cin >> value;
            cout << (myList.search(value) ? "Found.\n" : "Not found.\n");
            break;
        case 0:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice.\n";
        }
    } while (choice != 0);

    return 0;
}
