#include <iostream>
using namespace std;

class Employee {
public:
    virtual double calculateSalary() const = 0;
};

class FullTimeEmployee : public Employee {
private:
    double fixedSalary;
public:
    FullTimeEmployee(double salary) : fixedSalary(salary) {}
    double calculateSalary() const override {
        return fixedSalary;
    }
};

class PartTimeEmployee : public Employee {
private:
    double hoursWorked;
    double hourlyRate;
public:
    PartTimeEmployee(double hours, double rate) : hoursWorked(hours), hourlyRate(rate) {}
    double calculateSalary() const override {
        return hoursWorked * hourlyRate;
    }
};

int main() {
    FullTimeEmployee fullTime(50000);
    PartTimeEmployee partTime(120, 50);

    cout << "Full-Time Employee Salary: " << fullTime.calculateSalary() << endl;
    cout << "Part-Time Employee Salary: " << partTime.calculateSalary() << endl;

    return 0;
}
