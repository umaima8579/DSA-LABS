#include <iostream>
#include <string>
using namespace std;

template <typename T>
class AbstractStack {
public:
    virtual void push(T value) = 0;
    virtual T pop() = 0;
    virtual T top() const = 0;
    virtual bool isEmpty() const = 0;
    virtual bool isFull() const = 0;
    virtual ~AbstractStack() {}
};

template <typename T>
class myCarStack : public AbstractStack<T> {
private:
    T* arr;
    int maxSize;
    int topIndex;
public:
    myCarStack(int size = 8) {
        maxSize = size;
        arr = new T[maxSize];
        topIndex = -1;
    }

    ~myCarStack() {
        delete[] arr;
    }

    void push(T value) override {
        if (isFull()) {
            cout << "Parking lot is full. Cannot park more cars.\n";
            return;
        }
        arr[++topIndex] = value;
    }

    T pop() override {
        if (isEmpty()) {
            throw runtime_error("Parking lot is empty. No car to remove.");
        }
        return arr[topIndex--];
    }

    T top() const override {
        if (isEmpty()) {
            throw runtime_error("Parking lot is empty. No car on top.");
        }
        return arr[topIndex];
    }

    bool isEmpty() const override {
        return topIndex == -1;
    }

    bool isFull() const override {
        return topIndex == maxSize - 1;
    }

    int size() const {
        return topIndex + 1;
    }

    void display() const {
        if (isEmpty()) {
            cout << "Parking lot is empty.\n";
            return;
        }
        cout << "Cars currently parked (Top to Bottom):\n";
        for (int i = topIndex; i >= 0; --i) {
            cout << arr[i] << endl;
        }
    }

    bool searchCar(T carNumber) const {
        for (int i = 0; i <= topIndex; ++i) {
            if (arr[i] == carNumber)
                return true;
        }
        return false;
    }
};

int main() {
    myCarStack<string> parkingLot(8);
    int choice;
    string carNumber;

    do {
        cout << "\nParking Lot Menu:\n";
        cout << "1. View all parked cars\n";
        cout << "2. View car on top (last parked)\n";
        cout << "3. Total cars parked\n";
        cout << "4. Park a new car\n";
        cout << "5. Remove a car by number\n";
        cout << "6. Search for a car\n";
        cout << "7. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            parkingLot.display();
            break;
        case 2:
            try {
                cout << "Car on top: " << parkingLot.top() << endl;
            }
            catch (exception& e) {
                cout << e.what() << endl;
            }
            break;
        case 3:
            cout << "Total cars parked: " << parkingLot.size() << endl;
            break;
        case 4:
            if (!parkingLot.isFull()) {
                cout << "Enter car number to park: ";
                cin >> carNumber;
                parkingLot.push(carNumber);
                cout << "Car parked successfully.\n";
            }
            else {
                cout << "Parking lot is full.\n";
            }
            break;
        case 5:
            if (parkingLot.isEmpty()) {
                cout << "Parking lot is empty. No car to remove.\n";
                break;
            }
            cout << "Enter car number to remove: ";
            cin >> carNumber;
            if (!parkingLot.searchCar(carNumber)) {
                cout << "Car not found in parking lot.\n";
                break;
            }
            else {
                myCarStack<string> tempStack(8);
                while (parkingLot.top() != carNumber) {
                    tempStack.push(parkingLot.pop());
                }
                parkingLot.pop(); // remove the desired car
                cout << "Car removed successfully.\n";
                while (!tempStack.isEmpty()) {
                    parkingLot.push(tempStack.pop());
                }
            }
            break;
        case 6:
            cout << "Enter car number to search: ";
            cin >> carNumber;
            if (parkingLot.searchCar(carNumber)) {
                cout << "Car is present in parking lot.\n";
            }
            else {
                cout << "Car not found.\n";
            }
            break;
        case 7:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 7);

    return 0;
}
