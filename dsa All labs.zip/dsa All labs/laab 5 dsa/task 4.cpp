#include <iostream>
#include <stack>
#include <string>
using namespace std;

// Action type for the editor
enum ActionType {
    TYPE,    // Typing a character
    DELETE   // Deleting a character
};

// A structure to hold an action (either typing or deleting)
struct Action {
    ActionType actionType;  // Type of action
    char character;         // Character involved in the action
    string textState;       // The current state of the text before the action
};

class TextEditor {
private:
    string text;                          // The current text in the editor
    stack<Action> undoStack;               // Stack to store undo actions
    stack<Action> redoStack;               // Stack to store redo actions

public:
    // Function to display the current state of the text
    void displayText() {
        cout << "Current text: " << text << endl;
    }

    // Function to type a character and push the action to the undo stack
    void typeCharacter(char c) {
        Action action;
        action.actionType = TYPE;
        action.character = c;
        action.textState = text;
        text += c;  // Add the character to the text

        undoStack.push(action);  // Push the action to the undo stack
        while (!redoStack.empty()) {
            redoStack.pop();  // Clear the redo stack as new action is taken
        }
        displayText();
    }

    // Function to delete the last character and push the action to the undo stack
    void deleteCharacter() {
        if (text.empty()) {
            cout << "No text to delete.\n";
            return;
        }

        Action action;
        action.actionType = DELETE;
        action.character = text.back();  // Get the last character
        action.textState = text;
        text.pop_back();  // Remove the last character from the text

        undoStack.push(action);  // Push the action to the undo stack
        while (!redoStack.empty()) {
            redoStack.pop();  // Clear the redo stack as new action is taken
        }
        displayText();
    }

    // Function to undo the last action
    void undo() {
        if (undoStack.empty()) {
            cout << "No actions to undo.\n";
            return;
        }

        Action lastAction = undoStack.top();
        undoStack.pop();

        // If the action was typing, we delete the character
        if (lastAction.actionType == TYPE) {
            text = lastAction.textState;
        }
        // If the action was deleting, we add the character back
        else if (lastAction.actionType == DELETE) {
            text = lastAction.textState;
        }

        redoStack.push(lastAction);  // Push the undone action to the redo stack
        displayText();
    }

    // Function to redo the last undone action
    void redo() {
        if (redoStack.empty()) {
            cout << "No actions to redo.\n";
            return;
        }

        Action lastUndoneAction = redoStack.top();
        redoStack.pop();

        // If the action was typing, we retype the character
        if (lastUndoneAction.actionType == TYPE) {
            text += lastUndoneAction.character;
        }
        // If the action was deleting, we remove the character again
        else if (lastUndoneAction.actionType == DELETE) {
            text.pop_back();
        }

        undoStack.push(lastUndoneAction);  // Push the redone action to the undo stack
        displayText();
    }
};

int main() {
    TextEditor editor;
    int choice;
    char c;

    do {
        cout << "\nText Editor Menu:\n";
        cout << "1. Type a character\n";
        cout << "2. Delete a character\n";
        cout << "3. Undo\n";
        cout << "4. Redo\n";
        cout << "5. Display text\n";
        cout << "6. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter character to type: ";
            cin >> c;
            editor.typeCharacter(c);
            break;
        case 2:
            editor.deleteCharacter();
            break;
        case 3:
            editor.undo();
            break;
        case 4:
            editor.redo();
            break;
        case 5:
            editor.displayText();
            break;
        case 6:
            cout << "Exiting...\n";
            break;
        default:
            cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 6);

    return 0;
}
