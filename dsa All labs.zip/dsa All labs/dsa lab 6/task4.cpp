#include <iostream>
#include <queue>
using namespace std;

class TicketSystem {
    queue<int> tickets;

public:
    void enqueue(int ticket_id) {
        if (ticket_id < 1000 || ticket_id > 9999) {
            cout << "Invalid Ticket ID. Must be 4-digits.\n";
            return;
        }
        tickets.push(ticket_id);
        cout << "Ticket " << ticket_id << " added to the queue.\n";
    }

    void dequeue() {
        if (tickets.empty()) {
            cout << "No tickets to resolve.\n";
            return;
        }
        cout << "Resolving Ticket " << tickets.front() << endl;
        tickets.pop();
    }

    void front() {
        if (tickets.empty()) {
            cout << "No pending tickets.\n";
            return;
        }
        cout << "Next ticket to resolve: " << tickets.front() << endl;
    }

    void display() {
        if (tickets.empty()) {
            cout << "No pending tickets.\n";
            return;
        }
        queue<int> temp = tickets;
        cout << "Pending Tickets: ";
        while (!temp.empty()) {
            cout << temp.front() << " ";
            temp.pop();
        }
        cout << endl;
    }
};

int main() {
    TicketSystem system;
    int choice, ticket_id;

    do {
        cout << "\nCustomer Support Ticket System\n";
        cout << "1. Add New Ticket\n";
        cout << "2. Resolve Ticket\n";
        cout << "3. View Next Ticket\n";
        cout << "4. Display All Tickets\n";
        cout << "5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter 4-digit Ticket ID: ";
            cin >> ticket_id;
            system.enqueue(ticket_id);
            break;
        case 2:
            system.dequeue();
            break;
        case 3:
            system.front();
            break;
        case 4:
            system.display();
            break;
        case 5:
            cout << "Exiting system.\n";
            break;
        default:
            cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 5);

    return 0;
}
