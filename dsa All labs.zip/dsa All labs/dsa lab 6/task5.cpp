#include <iostream>
#include <queue>
#include <string>
using namespace std;

class PrintQueue {
    queue<string> documents;

public:
    void enqueue(string document_name) {
        documents.push(document_name);
        cout << "Document \"" << document_name << "\" added to the queue.\n";
    }

    void dequeue() {
        if (documents.empty()) {
            cout << "No documents to print.\n";
            return;
        }
        cout << "Printing: \"" << documents.front() << "\"\n";
        documents.pop();
    }

    void front() {
        if (documents.empty()) {
            cout << "No documents in the queue.\n";
            return;
        }
        cout << "Next document to print: \"" << documents.front() << "\"\n";
    }

    void display() {
        if (documents.empty()) {
            cout << "No documents in the queue.\n";
            return;
        }
        queue<string> temp = documents;
        cout << "Pending Documents:\n";
        while (!temp.empty()) {
            cout << "- " << temp.front() << endl;
            temp.pop();
        }
    }
};

int main() {
    PrintQueue printer;
    int choice;
    string name;

    do {
        cout << "\nPrinter Queue System\n";
        cout << "1. Add New Print Job\n";
        cout << "2. Print Next Document\n";
        cout << "3. View Front Document\n";
        cout << "4. Display All Pending Documents\n";
        cout << "5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;
        cin.ignore();

        switch (choice) {
        case 1:
            cout << "Enter document name: ";
            getline(cin, name);
            printer.enqueue(name);
            break;
        case 2:
            printer.dequeue();
            break;
        case 3:
            printer.front();
            break;
        case 4:
            printer.display();
            break;
        case 5:
            cout << "Exiting printer system.\n";
            break;
        default:
            cout << "Invalid choice. Try again.\n";
        }
    } while (choice != 5);

    return 0;
}
