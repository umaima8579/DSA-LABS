#include <iostream>
#include <stack>
using namespace std;

class QueueUsingStacks {
    stack<int> s1, s2;

    void transfer() {
        while (!s1.empty()) {
            s2.push(s1.top());
            s1.pop();
        }
    }

public:
    void enqueue(int value) {
        s1.push(value);
    }

    void dequeue() {
        if (s2.empty()) transfer();
        if (!s2.empty()) s2.pop();
        else cout << "Queue is empty\n";
    }

    void front() {
        if (s2.empty()) transfer();
        if (!s2.empty()) cout << s2.top() << endl;
        else cout << "Queue is empty\n";
    }

    void display() {
        stack<int> temp1 = s1, temp2;
        while (!temp1.empty()) {
            temp2.push(temp1.top());
            temp1.pop();
        }
        while (!s2.empty()) {
            cout << s2.top() << " ";
            s2.pop();
        }
        while (!temp2.empty()) {
            cout << temp2.top() << " ";
            temp2.pop();
        }
        cout << endl;
    }
};

int main() {
    QueueUsingStacks q;
    q.enqueue(10);
    q.enqueue(20);
    q.enqueue(30);
    q.display();
    q.front();
    q.dequeue();
    q.display();
    q.front();
}
